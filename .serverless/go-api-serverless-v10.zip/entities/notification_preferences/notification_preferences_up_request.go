package entities

type NotificationPreferencesUpRequest struct {
    ReceiveEmails bool `json:"receive_emails"`
}